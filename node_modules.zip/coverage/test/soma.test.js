const soma = require('../src/javascript/soma')

test('A Soma de 1 + 2 é igual a 3', () => {
    expect(soma(1, 2)).toBe(3);
});


test('A Soma de -10 + -20 é igual a -30', () => {
    expect(soma(-10, -20)).toBe(-30);
});


test('A Soma de -11 - +50  é igual a -61', () => {
    expect(soma(-11, -50)).toBe(-61);
});


test('A Soma de 49 + 48 é igual a 97', () => {
    expect(soma(49, 48)).toBe(97);
});


test('A Soma de 27 + 67 é igual a 94', () => {
    expect(soma(27, 67)).toBe(94);
});