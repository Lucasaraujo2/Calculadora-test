const multiplica = require('../src/javascript/multiplicacao')

test('A multiplicação de 7 * 7 é igual a 42', () => {
    expect(multiplica(7,7)).toBe(49);
});

test('A multiplicação de -59 * -21 é igual a 1240', () => {
    expect(multiplica(-59,-21)).toBe(1239);
});

test('A multiplicação de 87 * -500000  é igual a 43500000', () => {
    expect(multiplica(-87,-500000)).toBe(43500000);
});

test('A multiplicação de 49 * 48 é igual a 2352', () => {
    expect(multiplica(49,48)).toBe(2352);
});

test('A multiplicação de 0 * 52462  é igual a 0', () => {
    expect(multiplica(0,52462)).toBe(0);
});