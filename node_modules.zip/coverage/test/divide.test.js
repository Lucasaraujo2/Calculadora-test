const divide = require('../src/javascript/divisao')

test('A divisão de 500 / 77 é igual a 6.4935', () => {
    expect(divide(500,77)).toBe(6.49350649350649345);
});

test('A divisão de 0.97 / 0.38 é igual a 2.5526', () => {
    expect(divide(0.97, 0.38)).toBe(2.552631578947368);
});

test('A divisão de -500000 / 87  é igual a -5747.1264', () => {
    expect(divide(-87, -500000)).toBe(0.000174);
});

test('A divisão de 20 / 10 é igual a 2', () => {
    expect(divide(20, 10)).toBe(2);
});

test('A divisão de 35 / 7  é igual a 5', () => {
    expect(divide(35, 7 )).toBe(5);
});