const subitracao = require('../src/javascript/subtracao');

test('A Subtração de 1 - 2 é igual a -1', () => {
    expect(subitracao(1, 2)).toBe(-1);
});


test('A subtração de 1044 - 457 é igual a 587', () => {
    expect(subitracao(1044, 457)).toBe(587);
});


test('A subtração de 78900 - 14988  é igual a 63912', () => {
    expect(subitracao(78900, 14988)).toBe(63912);
});


test('A subitracao de 49 - 57 é igual a -8', () => {
    expect(subitracao(49, 57)).toBe(-8);
});


test('A subitracao de 27 - 67 é igual a -40', () => {
    expect(subitracao(27, 67)).toBe(-40);
});