function subtrai(a,b){
    return a - b;
};

// exporta o resultado
module.exports = subtrai;