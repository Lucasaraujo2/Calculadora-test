function multiplica(a,b){
    return a * b;
};

// exporta o resultado
module.exports = multiplica;