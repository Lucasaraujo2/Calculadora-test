function soma(a,b){
    return a + b;
};

// exporta o resultado
module.exports = soma;